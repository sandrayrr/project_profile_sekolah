-- migrations/schema.sql
DROP DATABASE IF EXISTS kasir_ujikom;
CREATE DATABASE kasir_ujikom CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE kasir_ujikom;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  username VARCHAR(50) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('admin','petugas','pimpinan','konsumen') NOT NULL DEFAULT 'konsumen',
  active TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE customers (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  phone VARCHAR(30),
  address VARCHAR(200)
);

CREATE TABLE payment_types (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(50) NOT NULL,
  active TINYINT(1) NOT NULL DEFAULT 1
);

CREATE TABLE products (
  id INT AUTO_INCREMENT PRIMARY KEY,
  sku VARCHAR(30) UNIQUE,
  name VARCHAR(120) NOT NULL,
  price DECIMAL(12,2) NOT NULL DEFAULT 0,
  stock INT NOT NULL DEFAULT 0
);

CREATE FUNCTION fn_generate_order_no() RETURNS VARCHAR(20)
DETERMINISTIC
BEGIN
  DECLARE code VARCHAR(20);
  SET code = DATE_FORMAT(NOW(), 'ORD%y%m%d%H%i%s');
  RETURN code;
END;

CREATE TABLE orders (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_no VARCHAR(20) NOT NULL UNIQUE,
  user_id INT NOT NULL,
  customer_id INT NULL,
  order_date DATETIME NOT NULL,
  subtotal DECIMAL(12,2) NOT NULL DEFAULT 0,
  discount DECIMAL(12,2) NOT NULL DEFAULT 0,
  tax DECIMAL(12,2) NOT NULL DEFAULT 0,
  total DECIMAL(12,2) NOT NULL DEFAULT 0,
  payment_type_id INT NOT NULL,
  paid_amount DECIMAL(12,2) NOT NULL DEFAULT 0,
  change_amount DECIMAL(12,2) NOT NULL DEFAULT 0,
  status ENUM('PAID','VOID') NOT NULL DEFAULT 'PAID',
  FOREIGN KEY (user_id) REFERENCES users(id),
  FOREIGN KEY (customer_id) REFERENCES customers(id),
  FOREIGN KEY (payment_type_id) REFERENCES payment_types(id)
);

CREATE TABLE order_items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_id INT NOT NULL,
  product_id INT NOT NULL,
  qty INT NOT NULL,
  price DECIMAL(12,2) NOT NULL,
  line_total DECIMAL(12,2) NOT NULL,
  FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
  FOREIGN KEY (product_id) REFERENCES products(id)
);

DELIMITER $$
CREATE TRIGGER trg_after_insert_order_item
AFTER INSERT ON order_items FOR EACH ROW
BEGIN
  UPDATE products SET stock = stock - NEW.qty WHERE id = NEW.product_id;
END$$

CREATE TRIGGER trg_after_delete_order_item
AFTER DELETE ON order_items FOR EACH ROW
BEGIN
  UPDATE products SET stock = stock + OLD.qty WHERE id = OLD.product_id;
END$$
DELIMITER ;

-- Optional: simple view for daily sales
CREATE VIEW vw_sales_daily AS
SELECT DATE(order_date) as tanggal, COUNT(*) as jumlah_transaksi, SUM(total) as omzet
FROM orders GROUP BY DATE(order_date);
