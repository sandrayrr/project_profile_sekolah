<?php require_once __DIR__ . '/../config/config.php'; require_once __DIR__ . '/../config/helpers.php'; ?>
<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Aplikasi Kasir UjiKom</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="assets/css/app.css">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="index.php">Kasir UjiKom</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <?php if (is_logged_in()): ?>
          <li class="nav-item"><a class="nav-link" href="index.php?page=dashboard">Dashboard</a></li>
          <?php if (has_role(['admin','petugas'])): ?>
            <li class="nav-item"><a class="nav-link" href="index.php?page=order_new">Transaksi</a></li>
          <?php endif; ?>
          <?php if (has_role(['admin','petugas'])): ?>
            <li class="nav-item"><a class="nav-link" href="index.php?page=products">Produk</a></li>
            <li class="nav-item"><a class="nav-link" href="index.php?page=customers">Konsumen</a></li>
            <li class="nav-item"><a class="nav-link" href="index.php?page=payment_types">Jenis Pembayaran</a></li>
          <?php endif; ?>
          <?php if (has_role(['admin'])): ?>
            <li class="nav-item"><a class="nav-link" href="index.php?page=users">Petugas</a></li>
            <li class="nav-item"><a class="nav-link" href="index.php?page=reports">Laporan</a></li>
          <?php endif; ?>
          <li class="nav-item"><a class="nav-link" href="index.php?page=orders_history">History</a></li>
        <?php endif; ?>
      </ul>
      <ul class="navbar-nav">
        <?php if (is_logged_in()): ?>
          <li class="nav-item"><span class="navbar-text me-3">Halo, <?= e($_SESSION['user']['name']); ?> (<?= e($_SESSION['user']['role']); ?>)</span></li>
          <li class="nav-item"><a class="btn btn-outline-light btn-sm" href="index.php?page=logout">Logout</a></li>
        <?php else: ?>
          <li class="nav-item"><a class="btn btn-outline-light btn-sm" href="index.php?page=login">Login</a></li>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</nav>
<div class="container py-3">
