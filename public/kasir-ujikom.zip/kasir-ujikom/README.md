# Aplikasi Kasir UjiKom (PHP + MySQL)

## Cara Menjalankan (XAMPP/Laragon)
1. Import database:
   - Buka **phpMyAdmin** → buat database `kasir_ujikom` (atau jalankan file `migrations/schema.sql`).
   - Jalankan juga `seeders/dummy.sql` untuk data awal (user, produk, dsb).
2. Copy folder `public/` ke `htdocs/kasir-ujikom/` (atau atur VirtualHost ke folder `public`).
3. Sesuaikan kredensial di `config/config.php` bila perlu.
4. Akses di browser: `http://localhost/kasir-ujikom/index.php`

### Akun login awal
- **admin** / `admin123`
- **petugas** / `admin123`
- **pimpinan** / `admin123`

## Fitur
- Login/Logout (role: admin, petugas, pimpinan, konsumen)
- CRUD: Produk, Konsumen, Jenis Pembayaran, User (khusus admin)
- Transaksi penjualan (keranjang belanja, bayar, cetak struk)
- History transaksi (filter tanggal & metode bayar)
- Laporan + Export CSV
- Trigger stok otomatis, function nomor order

## Catatan Keamanan
- Form dilindungi token CSRF sederhana
- Password disimpan `password_hash()`
- Query menggunakan prepared statement di area sensitif

## Instrumen Manual Testing (contoh)
| No | Skenario | Class | Method | Data Input | Expected Result | Actual Result | Status |
|----|----------|-------|--------|------------|-----------------|---------------|--------|
| 1  | Login sukses | Auth | do_login | admin/admin123 | Return true |  |  |
| 2  | Username salah | Auth | do_login | adminx/admin123 | Return false |  |  |
| 3  | SQL Injection login | Auth | do_login | ' or ''=' / ' or ''=' | Return false |  |  |
| 4  | Tambah produk | Produk | create | SKU-XXX | Data tersimpan |  |  |
| 5  | Transaksi & cetak struk | Order | checkout | keranjang>0 | Struk tercetak |  |  |

