-- seeders/dummy.sql
USE kasir_ujikom;

INSERT INTO users(name,username,password_hash,role,active) VALUES
('Administrator','admin', '$2y$10$y2.2qkRd2e2JY8Xv5c7x1eXo5TzqQK9X0L93e3S8Jr1K9v4a3O8cW', 'admin', 1), -- password: admin123
('Petugas 1','petugas', '$2y$10$y2.2qkRd2e2JY8Xv5c7x1eXo5TzqQK9X0L93e3S8Jr1K9v4a3O8cW', 'petugas', 1),
('Pimpinan','pimpinan', '$2y$10$y2.2qkRd2e2JY8Xv5c7x1eXo5TzqQK9X0L93e3S8Jr1K9v4a3O8cW', 'pimpinan', 1);

INSERT INTO customers(name,phone,address) VALUES
('Umum','-','-'),
('Rinda','08123456789','Bandung');

INSERT INTO payment_types(name,active) VALUES
('Tunai',1),('QRIS',1),('Kartu Debit',1);

INSERT INTO products(sku,name,price,stock) VALUES
('SKU-001','Indomie Goreng',3500,100),
('SKU-002','Sabun Mandi',8000,50),
('SKU-003','Minyak Goreng 1L',18000,30);
