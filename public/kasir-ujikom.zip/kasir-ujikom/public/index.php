<?php
require_once __DIR__ . '/../partials/header.php';

$page = $_GET['page'] ?? (is_logged_in() ? 'dashboard' : 'login');

$allowed = [
  'login','logout','dashboard','products','customers','payment_types','users',
  'order_new','orders_history','reports','print_receipt'
];

if (!in_array($page, $allowed, true)) {
  http_response_code(404);
  echo "<h1>404</h1><p>Halaman tidak ditemukan.</p>";
  require_once __DIR__ . '/../partials/footer.php';
  exit;
}

require_once __DIR__ . "/pages/{$page}.php";

require_once __DIR__ . '/../partials/footer.php';
