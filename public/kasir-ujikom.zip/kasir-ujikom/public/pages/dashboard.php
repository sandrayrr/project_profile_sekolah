<?php require_login(); ?>
<div class="row g-3">
  <div class="col-md-3">
    <div class="card shadow-sm">
      <div class="card-body">
        <div class="text-muted">Total Produk</div>
        <div class="h3">
          <?php $r=$mysqli->query("SELECT COUNT(*) c FROM products"); echo (int)$r->fetch_assoc()['c']; ?>
        </div>
      </div>
    </div>
  </div>
  <div class="col-md-3">
    <div class="card shadow-sm">
      <div class="card-body">
        <div class="text-muted">Total Konsumen</div>
        <div class="h3">
          <?php $r=$mysqli->query("SELECT COUNT(*) c FROM customers"); echo (int)$r->fetch_assoc()['c']; ?>
        </div>
      </div>
    </div>
  </div>
  <div class="col-md-3">
    <div class="card shadow-sm">
      <div class="card-body">
        <div class="text-muted">Transaksi Hari Ini</div>
        <div class="h3">
          <?php $r=$mysqli->query("SELECT COUNT(*) c FROM orders WHERE DATE(order_date)=CURDATE()"); echo (int)$r->fetch_assoc()['c']; ?>
        </div>
      </div>
    </div>
  </div>
  <div class="col-md-3">
    <div class="card shadow-sm">
      <div class="card-body">
        <div class="text-muted">Omzet Hari Ini</div>
        <div class="h3">
          <?php $r=$mysqli->query("SELECT COALESCE(SUM(total),0) s FROM orders WHERE DATE(order_date)=CURDATE()"); echo rupiah($r->fetch_assoc()['s']); ?>
        </div>
      </div>
    </div>
  </div>
</div>
