<?php require_login(); require_role(['admin','petugas']); check_csrf();
$action = $_GET['action'] ?? 'list';
if ($action === 'create' && $_SERVER['REQUEST_METHOD']==='POST') {
    $stmt=$mysqli->prepare("INSERT INTO customers(name,phone,address) VALUES(?,?,?)");
    $stmt->bind_param("sss", $_POST['name'], $_POST['phone'], $_POST['address']);
    $stmt->execute();
    header("Location: index.php?page=customers");
    exit;
}
if ($action === 'update' && $_SERVER['REQUEST_METHOD']==='POST') {
    $stmt=$mysqli->prepare("UPDATE customers SET name=?, phone=?, address=? WHERE id=?");
    $stmt->bind_param("sssi", $_POST['name'], $_POST['phone'], $_POST['address'], $_POST['id']);
    $stmt->execute();
    header("Location: index.php?page=customers");
    exit;
}
if ($action === 'delete') {
    $id=(int)($_GET['id']??0);
    $mysqli->query("DELETE FROM customers WHERE id=$id");
    header("Location: index.php?page=customers");
    exit;
}
$edit=null;
if ($action==='edit') {
    $id=(int)($_GET['id']??0);
    $edit=$mysqli->query("SELECT * FROM customers WHERE id=$id")->fetch_assoc();
}
?>
<div class="d-flex justify-content-between align-items-center mb-3">
  <h4>Konsumen</h4>
  <button class="btn btn-primary btn-sm" data-bs-toggle="collapse" data-bs-target="#form">Tambah</button>
</div>
<div id="form" class="collapse <?= $edit?'show':'' ?>">
  <form method="post" action="index.php?page=customers&action=<?= $edit?'update':'create' ?>" class="card card-body mb-3">
    <input type="hidden" name="csrf" value="<?= csrf_token(); ?>">
    <?php if ($edit): ?><input type="hidden" name="id" value="<?= (int)$edit['id'] ?>"><?php endif; ?>
    <div class="row g-2">
      <div class="col-md-4"><input class="form-control" name="name" placeholder="Nama" value="<?= e($edit['name']??'') ?>" required></div>
      <div class="col-md-4"><input class="form-control" name="phone" placeholder="HP" value="<?= e($edit['phone']??'') ?>"></div>
      <div class="col-md-4"><input class="form-control" name="address" placeholder="Alamat" value="<?= e($edit['address']??'') ?>"></div>
    </div>
    <div class="mt-2">
      <button class="btn btn-success btn-sm">Simpan</button>
      <a class="btn btn-secondary btn-sm" href="index.php?page=customers">Batal</a>
    </div>
  </form>
</div>
<table class="table table-striped table-sm">
  <thead><tr><th>Nama</th><th>HP</th><th>Alamat</th><th>Aksi</th></tr></thead>
  <tbody>
    <?php $res=$mysqli->query("SELECT * FROM customers ORDER BY id DESC");
    while($row=$res->fetch_assoc()): ?>
    <tr>
      <td><?= e($row['name']) ?></td>
      <td><?= e($row['phone']) ?></td>
      <td><?= e($row['address']) ?></td>
      <td>
        <a class="btn btn-warning btn-sm" href="index.php?page=customers&action=edit&id=<?= (int)$row['id'] ?>">Edit</a>
        <a class="btn btn-danger btn-sm" onclick="return confirm('Hapus?')" href="index.php?page=customers&action=delete&id=<?= (int)$row['id'] ?>">Hapus</a>
      </td>
    </tr>
    <?php endwhile; ?>
  </tbody>
</table>
