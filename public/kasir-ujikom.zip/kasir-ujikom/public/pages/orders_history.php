<?php require_login(); ?>
<h4>History Transaksi</h4>
<form class="row g-2 mb-3">
  <input type="hidden" name="page" value="orders_history">
  <div class="col-md-3"><input class="form-control" type="date" name="start" value="<?= e($_GET['start'] ?? date('Y-m-01')) ?>"></div>
  <div class="col-md-3"><input class="form-control" type="date" name="end" value="<?= e($_GET['end'] ?? date('Y-m-d')) ?>"></div>
  <div class="col-md-3">
    <select class="form-select" name="payment_type_id">
      <option value="">Semua Pembayaran</option>
      <?php $res=$mysqli->query("SELECT id,name FROM payment_types ORDER BY name");
      while($p=$res->fetch_assoc()): ?>
        <option value="<?= (int)$p['id'] ?>" <?= isset($_GET['payment_type_id']) && $_GET['payment_type_id']==$p['id']?'selected':'' ?>><?= e($p['name']) ?></option>
      <?php endwhile; ?>
    </select>
  </div>
  <div class="col-md-3"><button class="btn btn-primary w-100">Filter</button></div>
</form>
<table class="table table-sm table-striped">
  <thead><tr><th>No</th><th>Tanggal</th><th>Kasir</th><th>Customer</th><th>Pembayaran</th><th class="text-end">Total</th><th>Aksi</th></tr></thead>
  <tbody>
    <?php
    $start = $_GET['start'] ?? date('Y-m-01');
    $end = $_GET['end'] ?? date('Y-m-d');
    $pay = isset($_GET['payment_type_id']) && $_GET['payment_type_id']!=='' ? "AND o.payment_type_id=".(int)$_GET['payment_type_id'] : "";
    $sql = "SELECT o.*, u.name as kasir, c.name as customer, p.name as payname FROM orders o
            LEFT JOIN users u ON u.id=o.user_id
            LEFT JOIN customers c ON c.id=o.customer_id
            LEFT JOIN payment_types p ON p.id=o.payment_type_id
            WHERE DATE(o.order_date) BETWEEN '$start' AND '$end' $pay ORDER BY o.id DESC";
    $res=$mysqli->query($sql); while($row=$res->fetch_assoc()): ?>
    <tr>
      <td><?= e($row['order_no']) ?></td>
      <td><?= e($row['order_date']) ?></td>
      <td><?= e($row['kasir']) ?></td>
      <td><?= e($row['customer'] ?? 'Umum') ?></td>
      <td><?= e($row['payname']) ?></td>
      <td class="text-end"><?= rupiah($row['total']) ?></td>
      <td><a class="btn btn-sm btn-outline-secondary" href="index.php?page=print_receipt&id=<?= (int)$row['id'] ?>" target="_blank">Struk</a></td>
    </tr>
    <?php endwhile; ?>
  </tbody>
</table>
