<?php require_login();
$id = (int)($_GET['id'] ?? 0);
$sql = "SELECT o.*, u.name as kasir, c.name as customer, p.name as payname FROM orders o
        LEFT JOIN users u ON u.id=o.user_id
        LEFT JOIN customers c ON c.id=o.customer_id
        LEFT JOIN payment_types p ON p.id=o.payment_type_id
        WHERE o.id=$id";
$o = $mysqli->query($sql)->fetch_assoc();
if (!$o) { die("Order tidak ditemukan"); }
$items = $mysqli->query("SELECT i.*, pr.name FROM order_items i LEFT JOIN products pr ON pr.id=i.product_id WHERE i.order_id=$id");
?>
<style>
@media print {.no-print{display:none} body{background:#fff} .card{box-shadow:none;border:0}}
</style>
<div class="card">
  <div class="card-body">
    <div class="d-flex justify-content-between">
      <div>
        <h5>Toko Retail</h5>
        <div>Jl. Contoh No.1</div>
      </div>
      <div class="text-end">
        <div>No: <?= e($o['order_no']) ?></div>
        <div>Tgl: <?= e($o['order_date']) ?></div>
      </div>
    </div>
    <hr>
    <div>Kasir: <?= e($o['kasir']) ?> | Pembayaran: <?= e($o['payname']) ?></div>
    <div>Pelanggan: <?= e($o['customer'] ?? 'Umum') ?></div>
    <table class="table table-sm mt-2">
      <thead><tr><th>Item</th><th class="text-end">Harga</th><th class="text-end">Qty</th><th class="text-end">Subtotal</th></tr></thead>
      <tbody>
        <?php $sum=0; while($it=$items->fetch_assoc()): $line=$it['price']*$it['qty']; $sum+=$line; ?>
        <tr>
          <td><?= e($it['name']) ?></td>
          <td class="text-end"><?= rupiah($it['price']) ?></td>
          <td class="text-end"><?= (int)$it['qty'] ?></td>
          <td class="text-end"><?= rupiah($line) ?></td>
        </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
    <div class="text-end">
      <div>Subtotal: <?= rupiah($o['subtotal']) ?></div>
      <div>Diskon: <?= rupiah($o['discount']) ?></div>
      <div>Pajak: <?= rupiah($o['tax']) ?></div>
      <div class="fw-bold">Total: <?= rupiah($o['total']) ?></div>
      <div>Bayar: <?= rupiah($o['paid_amount']) ?></div>
      <div>Kembali: <?= rupiah($o['change_amount']) ?></div>
    </div>
    <div class="text-center mt-3">Terima kasih 🙏</div>
    <div class="no-print mt-3"><a href="index.php?page=orders_history" class="btn btn-secondary">Kembali</a> <button onclick="print()" class="btn btn-primary">Cetak</button></div>
  </div>
</div>
