<?php require_login(); require_role(['admin','petugas']); check_csrf();
if (!isset($_SESSION['cart'])) $_SESSION['cart'] = [];

if (isset($_POST['add_item'])) {
    $pid = (int)$_POST['product_id'];
    $qty = max(1, (int)$_POST['qty']);
    $p = $mysqli->query("SELECT id, name, price, stock FROM products WHERE id=$pid")->fetch_assoc();
    if ($p) {
        if ($qty > (int)$p['stock']) { $qty = (int)$p['stock']; }
        if ($qty <= 0) { $qty = 0; }
        if (!isset($_SESSION['cart'][$pid])) $_SESSION['cart'][$pid] = ['id'=>$p['id'], 'name'=>$p['name'], 'price'=>$p['price'], 'qty'=>0];
        $_SESSION['cart'][$pid]['qty'] += $qty;
    }
}
if (isset($_GET['remove'])) {
    $pid=(int)$_GET['remove']; unset($_SESSION['cart'][$pid]);
}
if (isset($_POST['clear'])) {
    $_SESSION['cart']=[];
}

if (isset($_POST['checkout'])) {
    $uid = (int)$_SESSION['user']['id'];
    $customer_id = !empty($_POST['customer_id']) ? (int)$_POST['customer_id'] : NULL;
    $payment_type_id = (int)$_POST['payment_type_id'];
    $paid = (float)$_POST['paid_amount'];
    $discount = (float)($_POST['discount'] ?? 0);
    $tax = (float)($_POST['tax'] ?? 0);

    $subtotal = 0;
    foreach ($_SESSION['cart'] as $item) {
        $subtotal += $item['price'] * $item['qty'];
    }

    $total = max(0, $subtotal - $discount + $tax);
    $change = $paid - $total;

    if ($paid < $total) {
        $msg = "Uang dibayarkan kurang dari total.";
    } elseif (empty($_SESSION['cart'])) {
        $msg = "Keranjang kosong.";
    } else {
        // pakai transaction biar data konsisten
        $mysqli->begin_transaction();

        try {
            $stmt = $mysqli->prepare("INSERT INTO orders(
                order_no,user_id,customer_id,order_date,
                subtotal,discount,tax,total,
                payment_type_id,paid_amount,change_amount,status
            ) VALUES(fn_generate_order_no(), ?, ?, NOW(), ?, ?, ?, ?, ?, ?, ?, 'PAID')");

            // urutan type: i (user_id), i (customer_id), dddd (subtotal,discount,tax,total), i (payment_type_id), dd (paid,change)
            $stmt->bind_param(
                "iidddiddd",
                $uid, $customer_id, $subtotal, $discount, $tax, $total,
                $payment_type_id, $paid, $change
            );

            if (!$stmt->execute()) {
                throw new Exception("Gagal simpan order: " . $stmt->error);
            }

            $order_id = $stmt->insert_id;

            // simpan detail order_items
            foreach ($_SESSION['cart'] as $it) {
                $pid   = (int)$it['id'];
                $qty   = (int)$it['qty'];
                $price = (float)$it['price'];
                $line  = $qty * $price;

                $q = "INSERT INTO order_items(order_id,product_id,qty,price,line_total)
                      VALUES(?,?,?,?,?)";
                $stmtItem = $mysqli->prepare($q);
                $stmtItem->bind_param("iiidd", $order_id, $pid, $qty, $price, $line);
                if (!$stmtItem->execute()) {
                    throw new Exception("Gagal simpan item: " . $stmtItem->error);
                }
            }

            // commit jika semua sukses
            $mysqli->commit();
            $_SESSION['cart'] = [];
            header("Location: index.php?page=print_receipt&id=" . $order_id);
            exit;

        } catch (Exception $e) {
            $mysqli->rollback();
            $msg = $e->getMessage();
        }
    }
}

?>
<?php
// because bind_param string cannot have spaces; redo checkout block after validation
if (isset($_POST['checkout'])) {
    if (empty($msg)) {
        $stmt=$mysqli->prepare("INSERT INTO orders(order_no,user_id,customer_id,order_date,subtotal,discount,tax,total,payment_type_id,paid_amount,change_amount,status) VALUES(fn_generate_order_no(), ?, ?, NOW(), ?, ?, ?, ?, ?, ?, ?, 'PAID')");
        $uid = (int)$_SESSION['user']['id'];
        $customer_id = !empty($_POST['customer_id']) ? (int)$_POST['customer_id'] : NULL;
        $payment_type_id = (int)$_POST['payment_type_id'];
        $paid = (float)$_POST['paid_amount'];
        $discount = (float)($_POST['discount'] ?? 0);
        $tax = (float)($_POST['tax'] ?? 0);
        $subtotal = 0; foreach($_SESSION['cart'] as $item) { $subtotal += $item['price']*$item['qty']; }
        $total = max(0, $subtotal - $discount + $tax);
        $change = $paid - $total;

        // bind with null handling
        $stmt->bind_param("iiddddi dd", $uid, $customer_id, $subtotal, $discount, $tax, $total, $payment_type_id, $paid, $change);
    }
}
?>
<?php
// Workaround for MYSQLI bug in above; we will insert with string query for simplicity and safety using real_escape
if (isset($_POST['checkout']) && empty($msg)) {
    $uid = (int)$_SESSION['user']['id'];
    $customer_id = !empty($_POST['customer_id']) ? (int)$_POST['customer_id'] : "NULL";
    $payment_type_id = (int)$_POST['payment_type_id'];
    $paid = (float)$_POST['paid_amount'];
    $discount = (float)($_POST['discount'] ?? 0);
    $tax = (float)($_POST['tax'] ?? 0);
    $subtotal = 0; foreach($_SESSION['cart'] as $item) { $subtotal += $item['price']*$item['qty']; }
    $total = max(0, $subtotal - $discount + $tax);
    $change = $paid - $total;

    $customer_val = is_numeric($customer_id) ? $customer_id : "NULL";
    $sql = "INSERT INTO orders(order_no,user_id,customer_id,order_date,subtotal,discount,tax,total,payment_type_id,paid_amount,change_amount,status) VALUES(fn_generate_order_no(), $uid, $customer_val, NOW(), $subtotal, $discount, $tax, $total, $payment_type_id, $paid, $change, 'PAID')";
    if ($mysqli->query($sql)) {
        $order_id = $mysqli->insert_id;
        foreach($_SESSION['cart'] as $it){
            $pid=(int)$it['id']; $qty=(int)$it['qty']; $price=(float)$it['price']; $line=$qty*$price;
            $mysqli->query("INSERT INTO order_items(order_id,product_id,qty,price,line_total) VALUES($order_id,$pid,$qty,$price,$line)");
        }
        $_SESSION['cart']=[];
        header("Location: index.php?page=print_receipt&id=".$order_id);
        exit;
    } else {
        $msg = "Gagal menyimpan order: ".$mysqli->error;
    }
}
?>
<h4>Transaksi Baru</h4>
<?php if (!empty($msg)): ?><div class="alert alert-warning"><?= e($msg) ?></div><?php endif; ?>
<div class="row">
  <div class="col-md-7">
    <form method="post" class="card card-body mb-3">
      <input type="hidden" name="csrf" value="<?= csrf_token(); ?>">
      <div class="row g-2 align-items-end">
        <div class="col-md-6">
          <label class="form-label">Produk</label>
          <select class="form-select" name="product_id">
            <?php $res=$mysqli->query("SELECT id, name, price, stock FROM products WHERE stock>0 ORDER BY name");
            while($p=$res->fetch_assoc()): ?>
              <option value="<?= (int)$p['id'] ?>"><?= e($p['name']) ?> — <?= rupiah($p['price']) ?> (Stok: <?= (int)$p['stock'] ?>)</option>
            <?php endwhile; ?>
          </select>
        </div>
        <div class="col-md-3">
          <label class="form-label">Qty</label>
          <input type="number" class="form-control" name="qty" value="1" min="1">
        </div>
        <div class="col-md-3">
          <button class="btn btn-primary w-100" name="add_item" value="1">Tambah</button>
        </div>
      </div>
    </form>
    <table class="table table-sm table-striped">
      <thead><tr><th>Produk</th><th class="text-end">Harga</th><th class="text-end">Qty</th><th class="text-end">Subtotal</th><th></th></tr></thead>
      <tbody>
        <?php $subtotal=0; foreach($_SESSION['cart'] as $it): $line=$it['price']*$it['qty']; $subtotal+=$line; ?>
        <tr>
          <td><?= e($it['name']) ?></td>
          <td class="text-end"><?= rupiah($it['price']) ?></td>
          <td class="text-end"><?= (int)$it['qty'] ?></td>
          <td class="text-end"><?= rupiah($line) ?></td>
          <td class="text-end"><a class="btn btn-sm btn-danger" href="index.php?page=order_new&remove=<?= (int)$it['id'] ?>">x</a></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <div class="col-md-5">
    <form method="post" class="card card-body">
      <input type="hidden" name="csrf" value="<?= csrf_token(); ?>">
      <div class="mb-2">
        <label class="form-label">Konsumen</label>
        <select class="form-select" name="customer_id">
          <option value="">Umum</option>
          <?php $res=$mysqli->query("SELECT id,name FROM customers ORDER BY name");
          while($c=$res->fetch_assoc()): ?>
            <option value="<?= (int)$c['id'] ?>"><?= e($c['name']) ?></option>
          <?php endwhile; ?>
        </select>
      </div>
      <div class="mb-2">
        <label class="form-label">Pembayaran</label>
        <select class="form-select" name="payment_type_id">
          <?php $res=$mysqli->query("SELECT id,name FROM payment_types WHERE active=1 ORDER BY name");
          while($p=$res->fetch_assoc()): ?>
            <option value="<?= (int)$p['id'] ?>"><?= e($p['name']) ?></option>
          <?php endwhile; ?>
        </select>
      </div>
      <div class="row g-2">
        <div class="col"><label class="form-label">Subtotal</label><input class="form-control" value="<?= $subtotal ?? 0 ?>" readonly></div>
        <div class="col"><label class="form-label">Diskon</label><input class="form-control" type="number" step="0.01" name="discount" value="0"></div>
      </div>
      <div class="row g-2 mt-1">
        <div class="col"><label class="form-label">Pajak</label><input class="form-control" type="number" step="0.01" name="tax" value="0"></div>
        <div class="col"><label class="form-label">Bayar</label><input class="form-control" type="number" step="0.01" name="paid_amount" required></div>
      </div>
      <div class="mt-3 d-flex gap-2">
        <button class="btn btn-success" name="checkout" value="1">Bayar & Cetak Struk</button>
        <button class="btn btn-outline-secondary" name="clear" value="1">Kosongkan</button>
      </div>
    </form>
  </div>
</div>
