<?php require_login(); require_role(['admin','petugas']); check_csrf();
$action = $_GET['action'] ?? 'list';

if ($action === 'create' && $_SERVER['REQUEST_METHOD']==='POST') {
    $stmt=$mysqli->prepare("INSERT INTO products(sku,name,price,stock) VALUES(?,?,?,?)");
    $stmt->bind_param("ssdi", $_POST['sku'], $_POST['name'], $_POST['price'], $_POST['stock']);
    $stmt->execute();
    header("Location: index.php?page=products");
    exit;
}
if ($action === 'update' && $_SERVER['REQUEST_METHOD']==='POST') {
    $stmt=$mysqli->prepare("UPDATE products SET sku=?, name=?, price=?, stock=? WHERE id=?");
    $stmt->bind_param("ssdii", $_POST['sku'], $_POST['name'], $_POST['price'], $_POST['stock'], $_POST['id']);
    $stmt->execute();
    header("Location: index.php?page=products");
    exit;
}
if ($action === 'delete') {
    $id=(int)($_GET['id']??0);
    $mysqli->query("DELETE FROM products WHERE id=$id");
    header("Location: index.php?page=products");
    exit;
}
$edit=null;
if ($action==='edit') {
    $id=(int)($_GET['id']??0);
    $edit=$mysqli->query("SELECT * FROM products WHERE id=$id")->fetch_assoc();
}
?>
<div class="d-flex justify-content-between align-items-center mb-3">
  <h4>Produk</h4>
  <button class="btn btn-primary btn-sm" data-bs-toggle="collapse" data-bs-target="#form">Tambah</button>
</div>
<div id="form" class="collapse <?= $edit?'show':'' ?>">
  <form method="post" action="index.php?page=products&action=<?= $edit?'update':'create' ?>" class="card card-body mb-3">
    <input type="hidden" name="csrf" value="<?= csrf_token(); ?>">
    <?php if ($edit): ?><input type="hidden" name="id" value="<?= (int)$edit['id'] ?>"><?php endif; ?>
    <div class="row g-2">
      <div class="col-md-3"><input class="form-control" name="sku" placeholder="SKU" value="<?= e($edit['sku']??'') ?>" required></div>
      <div class="col-md-5"><input class="form-control" name="name" placeholder="Nama Produk" value="<?= e($edit['name']??'') ?>" required></div>
      <div class="col-md-2"><input class="form-control" type="number" step="0.01" name="price" placeholder="Harga" value="<?= e($edit['price']??'') ?>" required></div>
      <div class="col-md-2"><input class="form-control" type="number" name="stock" placeholder="Stok" value="<?= e($edit['stock']??'') ?>" required></div>
    </div>
    <div class="mt-2">
      <button class="btn btn-success btn-sm">Simpan</button>
      <a class="btn btn-secondary btn-sm" href="index.php?page=products">Batal</a>
    </div>
  </form>
</div>
<table class="table table-striped table-sm">
  <thead><tr><th>SKU</th><th>Nama</th><th class="text-end">Harga</th><th class="text-end">Stok</th><th>Aksi</th></tr></thead>
  <tbody>
    <?php $res=$mysqli->query("SELECT * FROM products ORDER BY id DESC");
    while($row=$res->fetch_assoc()): ?>
    <tr>
      <td><?= e($row['sku']) ?></td>
      <td><?= e($row['name']) ?></td>
      <td class="text-end"><?= rupiah($row['price']) ?></td>
      <td class="text-end"><?= (int)$row['stock'] ?></td>
      <td>
        <a class="btn btn-warning btn-sm" href="index.php?page=products&action=edit&id=<?= (int)$row['id'] ?>">Edit</a>
        <a class="btn btn-danger btn-sm" onclick="return confirm('Hapus?')" href="index.php?page=products&action=delete&id=<?= (int)$row['id'] ?>">Hapus</a>
      </td>
    </tr>
    <?php endwhile; ?>
  </tbody>
</table>
