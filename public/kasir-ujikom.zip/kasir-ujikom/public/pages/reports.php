<?php require_login(); require_role(['admin']); ?>
<h4>Laporan Penjualan</h4>
<form class="row g-2 mb-3" method="get">
  <input type="hidden" name="page" value="reports">
  <div class="col-md-3"><input class="form-control" type="date" name="start" value="<?= e($_GET['start'] ?? date('Y-m-01')) ?>"></div>
  <div class="col-md-3"><input class="form-control" type="date" name="end" value="<?= e($_GET['end'] ?? date('Y-m-d')) ?>"></div>
  <div class="col-md-3"><button class="btn btn-primary w-100">Tampilkan</button></div>
  <div class="col-md-3"><a class="btn btn-outline-success w-100" href="index.php?page=reports&export=csv&start=<?= e($_GET['start'] ?? date('Y-m-01')) ?>&end=<?= e($_GET['end'] ?? date('Y-m-d')) ?>">Export CSV</a></div>
</form>
<?php
$start = $_GET['start'] ?? date('Y-m-01');
$end = $_GET['end'] ?? date('Y-m-d');

if (($_GET['export'] ?? '') === 'csv') {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="laporan_'.$start.'_to_'.$end.'.csv"');
    $out = fopen('php://output', 'w');
    fputcsv($out, ['No Order','Tanggal','Kasir','Total']);
    $res=$mysqli->query("SELECT o.order_no, o.order_date, u.name, o.total FROM orders o LEFT JOIN users u ON u.id=o.user_id WHERE DATE(o.order_date) BETWEEN '$start' AND '$end'");
    while($r=$res->fetch_row()){ fputcsv($out, $r); }
    fclose($out);
    exit;
}
?>
<table class="table table-sm table-striped">
  <thead><tr><th>No</th><th>Tanggal</th><th>Kasir</th><th class="text-end">Total</th></tr></thead>
  <tbody>
    <?php $res=$mysqli->query("SELECT o.order_no, o.order_date, u.name as kasir, o.total FROM orders o LEFT JOIN users u ON u.id=o.user_id WHERE DATE(o.order_date) BETWEEN '$start' AND '$end' ORDER BY o.id DESC");
    $sum=0; while($row=$res->fetch_assoc()): $sum+=$row['total']; ?>
    <tr>
      <td><?= e($row['order_no']) ?></td>
      <td><?= e($row['order_date']) ?></td>
      <td><?= e($row['kasir']) ?></td>
      <td class="text-end"><?= rupiah($row['total']) ?></td>
    </tr>
    <?php endwhile; ?>
  </tbody>
  <tfoot>
    <tr><th colspan="3" class="text-end">Grand Total</th><th class="text-end"><?= rupiah($sum) ?></th></tr>
  </tfoot>
</table>
