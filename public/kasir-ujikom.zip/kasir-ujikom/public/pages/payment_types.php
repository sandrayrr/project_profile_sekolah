<?php require_login(); require_role(['admin','petugas']); check_csrf();
$action = $_GET['action'] ?? 'list';
if ($action === 'create' && $_SERVER['REQUEST_METHOD']==='POST') {
    $stmt=$mysqli->prepare("INSERT INTO payment_types(name,active) VALUES(?,1)");
    $stmt->bind_param("s", $_POST['name']);
    $stmt->execute();
    header("Location: index.php?page=payment_types");
    exit;
}
if ($action === 'update' && $_SERVER['REQUEST_METHOD']==='POST') {
    $active = isset($_POST['active']) ? 1 : 0;
    $stmt=$mysqli->prepare("UPDATE payment_types SET name=?, active=? WHERE id=?");
    $stmt->bind_param("sii", $_POST['name'], $active, $_POST['id']);
    $stmt->execute();
    header("Location: index.php?page=payment_types");
    exit;
}
if ($action === 'delete') {
    $id=(int)($_GET['id']??0);
    $mysqli->query("DELETE FROM payment_types WHERE id=$id");
    header("Location: index.php?page=payment_types");
    exit;
}
$edit=null;
if ($action==='edit') {
    $id=(int)($_GET['id']??0);
    $edit=$mysqli->query("SELECT * FROM payment_types WHERE id=$id")->fetch_assoc();
}
?>
<div class="d-flex justify-content-between align-items-center mb-3">
  <h4>Jenis Pembayaran</h4>
  <button class="btn btn-primary btn-sm" data-bs-toggle="collapse" data-bs-target="#form">Tambah</button>
</div>
<div id="form" class="collapse <?= $edit?'show':'' ?>">
  <form method="post" action="index.php?page=payment_types&action=<?= $edit?'update':'create' ?>" class="card card-body mb-3">
    <input type="hidden" name="csrf" value="<?= csrf_token(); ?>">
    <?php if ($edit): ?><input type="hidden" name="id" value="<?= (int)$edit['id'] ?>"><?php endif; ?>
    <div class="row g-2">
      <div class="col-md-6"><input class="form-control" name="name" placeholder="Nama" value="<?= e($edit['name']??'') ?>" required></div>
      <?php if ($edit): ?>
        <div class="col-md-6"><div class="form-check mt-2"><input class="form-check-input" type="checkbox" name="active" <?= $edit['active']?'checked':'' ?>> <label class="form-check-label">Aktif</label></div></div>
      <?php endif; ?>
    </div>
    <div class="mt-2">
      <button class="btn btn-success btn-sm">Simpan</button>
      <a class="btn btn-secondary btn-sm" href="index.php?page=payment_types">Batal</a>
    </div>
  </form>
</div>
<table class="table table-striped table-sm">
  <thead><tr><th>Nama</th><th>Status</th><th>Aksi</th></tr></thead>
  <tbody>
    <?php $res=$mysqli->query("SELECT * FROM payment_types ORDER BY id DESC");
    while($row=$res->fetch_assoc()): ?>
    <tr>
      <td><?= e($row['name']) ?></td>
      <td><?= $row['active']?'Aktif':'Nonaktif' ?></td>
      <td>
        <a class="btn btn-warning btn-sm" href="index.php?page=payment_types&action=edit&id=<?= (int)$row['id'] ?>">Edit</a>
        <a class="btn btn-danger btn-sm" onclick="return confirm('Hapus?')" href="index.php?page=payment_types&action=delete&id=<?= (int)$row['id'] ?>">Hapus</a>
      </td>
    </tr>
    <?php endwhile; ?>
  </tbody>
</table>
