<?php
// config/helpers.php
function is_logged_in() {
    return isset($_SESSION['user']);
}

function require_login() {
    if (!is_logged_in()) {
        header('Location: index.php?page=login');
        exit;
    }
}

function has_role($roles) {
    if (!is_array($roles)) $roles = [$roles];
    return is_logged_in() && in_array($_SESSION['user']['role'], $roles, true);
}

function require_role($roles) {
    if (!has_role($roles)) {
        http_response_code(403);
        echo "<h1>403 Forbidden</h1><p>Anda tidak memiliki akses ke halaman ini.</p>";
        exit;
    }
}

function e($str) {
    return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8');
}

function rupiah($number) {
    return "Rp " . number_format((float)$number, 0, ',', '.');
}

function csrf_token() {
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(16));
    }
    return $_SESSION['csrf'];
}

function check_csrf() {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (!isset($_POST['csrf']) || $_POST['csrf'] !== ($_SESSION['csrf'] ?? '')) {
            http_response_code(400);
            die("Invalid CSRF token");
        }
    }
}
?>
